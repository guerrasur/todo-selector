"""Rappi Partners.

FLUJO OBSERVADO (captura del usuario):
  - Cada producto es una tarjeta con imagen, nombre, SKU, badge de estado
    ("Apagados"), descripcion, precio, un toggle a la derecha y un lapiz.
  - El badge de estado da una segunda fuente para leer disponibilidad.

OJO CON LAS TIENDAS:
  La URL trae varios storeIds. Si hay que apagar en TODAS, este modulo
  tiene que iterar cambiando storeId en la URL. Ver STORE_IDS abajo.

=========================================================================
 SELECTORES PENDIENTES DE CONFIRMAR EN VIVO  ->  buscar "TODO-SELECTOR"
=========================================================================
"""

from typing import Optional

from .base import PlataformaBase, ResultadoEstado


class Rappi(PlataformaBase):
    nombre = "rappi"

    BRAND_ID = "AR75000"
    # Solo la tienda de Carabelas - Turbo.
    # Al apagar en Turbo, tambien se apaga en Rappi normal (confirmado por el
    # usuario). Si en algun momento eso deja de pasar, agregar mas ids aca.
    # TODO-CONFIRMAR: cual de estos ids es Turbo Carabelas.
    STORE_ID_TURBO = "AR221056"
    STORE_IDS = [STORE_ID_TURBO]
    TODAS_LAS_TIENDAS = ["AR240053", "AR240052", "AR221056", "AR236447", "AR223022"]

    BADGE_APAGADO = "Apagados"

    def __init__(self, page, store_id: str = None):
        super().__init__(page)
        self.store_id = store_id or self.STORE_IDS[0]

    @property
    def url_menu(self) -> str:
        ids = ",".join(self.STORE_IDS)
        return (
            f"https://partners.rappi.com/menu"
            f"?brandId={self.BRAND_ID}&storeIds={ids}&storeId={self.store_id}"
        )

    async def asegurar_sesion(self) -> bool:
        await self.ir_al_menu()

        if await self.page.locator('input[type="password"]').count() > 0:
            return False

        # TODO-SELECTOR: confirmar un elemento que pruebe que el menu cargo.
        try:
            await self.page.wait_for_selector(
                'text=/precio/i', timeout=15000
            )
            return True
        except Exception:
            return False

    def _tarjeta(self, nombre_remoto: str):
        """Locator de la tarjeta del producto.

        TODO-SELECTOR: ajustar al contenedor real de la tarjeta.
        """
        texto = self.page.get_by_text(nombre_remoto, exact=True).first
        return texto.locator(
            "xpath=ancestor-or-self::*[self::li or self::article or self::div][3]"
        )

    async def leer_estado(self, nombre_remoto: str) -> Optional[ResultadoEstado]:
        await self.ir_al_menu()
        tarjeta = self._tarjeta(nombre_remoto)

        if await tarjeta.count() == 0:
            return None

        # Fuente 1: el badge de texto
        texto = await tarjeta.inner_text()
        if self.BADGE_APAGADO.lower() in texto.lower():
            return ResultadoEstado(disponible=False, detalle="badge Apagados")

        # Fuente 2: el toggle
        toggle = tarjeta.locator(
            'input[type="checkbox"], [role="switch"], button[aria-checked]'
        ).first
        if await toggle.count() > 0:
            aria = await toggle.get_attribute("aria-checked")
            if aria is not None:
                return ResultadoEstado(disponible=(aria == "true"), detalle=f"aria={aria}")
            try:
                return ResultadoEstado(disponible=await toggle.is_checked(),
                                       detalle="checkbox")
            except Exception:
                pass

        return ResultadoEstado(disponible=True, detalle="sin badge de apagado")

    async def apagar(self, nombre_remoto: str, por_hoy: bool = True) -> bool:
        estado = await self.leer_estado(nombre_remoto)
        if estado is None:
            return False
        if not estado.disponible:
            return True

        tarjeta = self._tarjeta(nombre_remoto)
        toggle = tarjeta.locator(
            'input[type="checkbox"], [role="switch"], button[aria-checked]'
        ).first
        await toggle.click()
        await self.page.wait_for_timeout(1500)

        # TODO-SELECTOR: Rappi tambien ofrece "por hoy" vs "indefinidamente".
        # Confirmar los textos exactos del dialogo y ajustar estos patrones.
        patron = r"(por hoy|hoy)" if por_hoy else r"(indefinid|siempre)"
        try:
            opcion = self.page.get_by_text(
                __import__("re").compile(patron, __import__("re").I)
            ).first
            if await opcion.count() > 0:
                await opcion.click(timeout=8000)
                await self.page.wait_for_timeout(1000)
        except Exception:
            pass

        # TODO-SELECTOR: puede haber un boton final de "Guardar"/"Confirmar".
        for txt in ["Guardar", "Confirmar", "Aceptar", "Aplicar"]:
            btn = self.page.get_by_role("button", name=txt)
            if await btn.count() > 0:
                await btn.first.click()
                break

        await self.page.wait_for_timeout(3000)
        return await self._confirmar(nombre_remoto, esperado_disponible=False)

    async def prender(self, nombre_remoto: str) -> bool:
        estado = await self.leer_estado(nombre_remoto)
        if estado is None:
            return False
        if estado.disponible:
            return True

        tarjeta = self._tarjeta(nombre_remoto)
        toggle = tarjeta.locator(
            'input[type="checkbox"], [role="switch"], button[aria-checked]'
        ).first
        await toggle.click()
        await self.page.wait_for_timeout(2500)

        return await self._confirmar(nombre_remoto, esperado_disponible=True)

    async def _confirmar(self, nombre_remoto: str, esperado_disponible: bool) -> bool:
        await self.page.reload(wait_until="domcontentloaded")
        await self.page.wait_for_timeout(4000)
        estado = await self.leer_estado(nombre_remoto)
        return estado is not None and estado.disponible == esperado_disponible
