"""PedidosYa Partner.

FLUJO OBSERVADO (capturas del usuario):
  1. Lista de productos agrupados por categoria (Ensaladas, Wraps, ...)
  2. Cada producto tiene un toggle a la izquierda del nombre
  3. Al clickear el toggle de un producto PRENDIDO, se abre un popup con:
       - titulo = nombre del producto
       - "No disponible por hoy"          (punto amarillo)
       - "No disponible indefinidamente"  (punto gris)
  4. Al clickear el toggle de un producto APAGADO, presumiblemente lo
     prende directo (VERIFICAR en vivo).

=========================================================================
 SELECTORES PENDIENTES DE CONFIRMAR EN VIVO  ->  buscar "TODO-SELECTOR"
=========================================================================
"""

from typing import Optional

from .base import PlataformaBase, ResultadoEstado


class PedidosYa(PlataformaBase):
    nombre = "pedidosya"
    url_menu = "https://web-ar.us.restaurant-partners.com/menus/PY_AR/460348"

    # --- Textos del popup (confirmados por captura) ---
    TXT_POR_HOY = "No disponible por hoy"
    TXT_INDEFINIDO = "No disponible indefinidamente"

    async def asegurar_sesion(self) -> bool:
        await self.ir_al_menu()

        # TODO-SELECTOR: confirmar como se ve la pantalla de login.
        # Heuristica: si aparece un campo de password, la sesion expiro.
        if await self.page.locator('input[type="password"]').count() > 0:
            return False

        # TODO-SELECTOR: confirmar que este selector identifica la lista cargada.
        try:
            await self.page.wait_for_selector("text=Wraps", timeout=15000)
            return True
        except Exception:
            return False

    def _fila(self, nombre_remoto: str):
        """Devuelve el locator de la fila del producto.

        TODO-SELECTOR: ajustar. Estrategia actual: buscar el texto exacto
        y subir al contenedor de la fila. Ojo con nombres que son prefijo
        de otros ('Wrap caesar' vs 'Wrap caesar con batatas') -> usamos
        exact=True para no agarrar el equivocado.
        """
        texto = self.page.get_by_text(nombre_remoto, exact=True).first
        return texto.locator(
            "xpath=ancestor-or-self::*[self::li or self::tr or self::div][1]"
        )

    async def leer_estado(self, nombre_remoto: str) -> Optional[ResultadoEstado]:
        await self.ir_al_menu()
        fila = self._fila(nombre_remoto)

        if await fila.count() == 0:
            return None

        # TODO-SELECTOR: identificar como distinguir toggle ON vs OFF.
        # Opciones tipicas: input[type=checkbox] con :checked, o
        # aria-checked="true", o una clase CSS distinta.
        toggle = fila.locator(
            'input[type="checkbox"], [role="switch"], button[aria-checked]'
        ).first

        if await toggle.count() == 0:
            return ResultadoEstado(disponible=False, detalle="toggle no encontrado")

        aria = await toggle.get_attribute("aria-checked")
        if aria is not None:
            return ResultadoEstado(disponible=(aria == "true"), detalle=f"aria={aria}")

        try:
            marcado = await toggle.is_checked()
            return ResultadoEstado(disponible=marcado, detalle="checkbox")
        except Exception:
            clases = await toggle.get_attribute("class") or ""
            return ResultadoEstado(disponible=False, detalle=f"class={clases}")

    async def apagar(self, nombre_remoto: str, por_hoy: bool = True) -> bool:
        estado = await self.leer_estado(nombre_remoto)
        if estado is None:
            return False
        if not estado.disponible:
            return True  # ya estaba apagado

        fila = self._fila(nombre_remoto)
        toggle = fila.locator(
            'input[type="checkbox"], [role="switch"], button[aria-checked]'
        ).first
        await toggle.click()
        await self.page.wait_for_timeout(1500)

        # El popup ofrece las dos opciones
        opcion = self.TXT_POR_HOY if por_hoy else self.TXT_INDEFINIDO
        try:
            await self.page.get_by_text(opcion, exact=False).first.click(timeout=8000)
        except Exception:
            return False

        await self.page.wait_for_timeout(3000)
        return await self._confirmar(nombre_remoto, esperado_disponible=False)

    async def prender(self, nombre_remoto: str) -> bool:
        estado = await self.leer_estado(nombre_remoto)
        if estado is None:
            return False
        if estado.disponible:
            return True

        fila = self._fila(nombre_remoto)
        toggle = fila.locator(
            'input[type="checkbox"], [role="switch"], button[aria-checked]'
        ).first
        await toggle.click()
        await self.page.wait_for_timeout(2000)

        # TODO-SELECTOR: verificar si al prender tambien aparece un popup
        # de confirmacion. Si aparece, clickear el boton correspondiente aca.

        return await self._confirmar(nombre_remoto, esperado_disponible=True)

    async def _confirmar(self, nombre_remoto: str, esperado_disponible: bool) -> bool:
        """Recarga y relee: no confiamos en que el click alcanzo."""
        await self.page.reload(wait_until="domcontentloaded")
        await self.page.wait_for_timeout(4000)
        estado = await self.leer_estado(nombre_remoto)
        return estado is not None and estado.disponible == esperado_disponible
