"""Carga inicial de productos con sus nombres en cada plataforma.

IMPORTANTE: los nombres difieren mucho entre PedidosYa y Rappi.
Formato: (nombre_canonico, categoria, nombre_en_pedidosya, nombre_en_rappi)
Si un nombre es None, ese producto NO existe en esa plataforma.

REVISAR LAS MARCAS "DUDA" ANTES DE USAR EN PRODUCCION.
"""

from .database import SessionLocal
from .models import Producto, AliasPlataforma, EstadoItem

# (canonico, categoria, pedidosya, rappi)
PRODUCTOS = [
    # ---------------- Ensaladas ----------------
    ("Caesar", "Ensaladas", "Caesar", "Ensalada caesar"),
    ("Cobb", "Ensaladas", "Cobb", "Cobb"),
    ("Clasica", "Ensaladas", "Clasica", "Ensalada clasica"),
    ("Brie", "Ensaladas", "Brie", "Ensalada Brie"),
    ("Atun", "Ensaladas", "Atun", "Ensalada con atun"),
    ("Falafel", "Ensaladas", "Falafel", "Ensalada de falafel"),
    ("Cala", "Ensaladas", "Cala", "Ensalada cala"),
    ("Porto", "Ensaladas", "Porto", "Ensalada porto"),

    # DUDA: "Mexicana" figura en PedidosYa pero no aparece en Rappi.
    ("Mexicana", "Ensaladas", "Mexicana", None),

    # DUDA: "Ensalada con Peras" figura en Rappi pero no en PedidosYa.
    ("Ensalada con Peras", "Ensaladas", None, "Ensalada con Peras"),

    # ---------------- Wraps ----------------
    ("Wrap brie", "Wraps", "Wrap brie", "Wrap Brie"),
    ("Wrap caesar", "Wraps", "Wrap caesar", "Wrap caesar"),
    ("Wrap Hummus", "Wraps", "Wrap Hummus", "Wrap Hummus"),
    ("Wrap de pollo a la Toscana", "Wraps",
     "Wrap de pollo a la Toscana", "Wrap de pollo a la toscana"),

    # DUDA IMPORTANTE: en PedidosYa dice "con batatas", en Rappi "con ensalada".
    # Asumo que son el mismo producto con distinta guarnicion en el nombre.
    # CONFIRMAR: son el mismo plato o son distintos?
    ("Wrap caesar con batatas", "Wraps",
     "Wrap caesar con batatas", "Wrap caesar con ensalada"),
    ("Wrap de Atun con batatas", "Wraps",
     "Wrap de Atun con batatas", "Wrap de atun con ensalada"),
    ("Wrap hummus con batatas", "Wraps",
     "Wrap hummus con batatas", "Wrap Hummus con ensalada"),
    ("Wrap toscano con batatas", "Wraps",
     "Wrap toscano con batatas", "Wrap Toscano con ensalada"),

    # DUDA: "Wrap de atun" (sin guarnicion) solo esta en Rappi.
    ("Wrap de atun", "Wraps", None, "Wrap de atun"),
    # DUDA: "Wrap Brie con ensalada" solo esta en Rappi.
    ("Wrap Brie con ensalada", "Wraps", None, "Wrap Brie con ensalada"),

    # ---------------- Platos ----------------
    # En PedidosYa estos figuran bajo "Ensaladas"; en Rappi bajo "Plato del Dia".
    # Los dejo como categoria propia para que se vean juntos en la UI.
    ("Arroz Chaufa", "Platos", "Arroz Chaufa", "Arroz Chaufa"),
    ("Risotto", "Platos", "Risotto", "Risotto de Hongos"),
    ("Pastel de papa", "Platos", "Pastel de papa", "Pastel de Papa"),
    ("Ravioles con crema de hongos", "Platos",
     "Ravioles con crema de hongos", "Ravioles con Crema de hongos"),
    ("Guiso de lentejas", "Platos", "Guiso de lentejas", "Guiso de lentejas"),
    ("Guiso de lentejas vegetariano", "Platos",
     "Guiso de lentejas vegetariano", "Guiso de lentejas vegetariano"),

    # DUDA: la Suprema solo aparece en Rappi.
    ("Suprema a la Crema de Limon con Pure", "Platos",
     None, "Suprema a la Crema de Limon con Pure"),

    # ---------------- Bebidas ----------------
    ("Agua sin gas", "Bebidas", "Agua sin gas", "Villavicencio sin gas 500 ml"),
    ("Agua con gas", "Bebidas", "Agua con gas", "Villavicencio con gas 500 ml"),
    ("Coca Cola", "Bebidas", "Coca Cola", "Coca-cola sabor original 500 ml"),

    # DUDA: en la lista de PedidosYa figura "Coca Coca Zero" (parece un typo,
    # pero puede estar asi en el portal). CONFIRMAR el nombre exacto.
    ("Coca Zero", "Bebidas", "Coca Coca Zero", "Coca-cola sin azucar 500 ml"),
]

PLATAFORMAS = ["pedidosya", "rappi"]


def sembrar():
    db = SessionLocal()
    try:
        if db.query(Producto).count() > 0:
            return  # ya sembrado

        for i, (canonico, categoria, n_py, n_rappi) in enumerate(PRODUCTOS):
            p = Producto(nombre=canonico, categoria=categoria, orden=i)
            db.add(p)
            db.flush()

            # Alias solo si difiere del canonico
            if n_py and n_py != canonico:
                db.add(AliasPlataforma(producto_id=p.id, plataforma="pedidosya",
                                       nombre_remoto=n_py))
            if n_rappi and n_rappi != canonico:
                db.add(AliasPlataforma(producto_id=p.id, plataforma="rappi",
                                       nombre_remoto=n_rappi))

            # Solo creamos estado en las plataformas donde el producto existe
            for plat, nombre in (("pedidosya", n_py), ("rappi", n_rappi)):
                if nombre is None:
                    continue
                db.add(EstadoItem(producto_id=p.id, plataforma=plat,
                                  estado=EstadoItem.DESCONOCIDO))

        db.commit()
    finally:
        db.close()
